// =============================================================================
//  Danish SAF-T Financial — C# Data Models (Demo Version)
//  Namespace: urn:StandardAuditFile-Taxation-Financial:DK
//  Covers: All Tier 1, 2, and 3 fraud detection examples
//          (internal consistency, statistical anomalies, SAF-T vs Peppol)
// =============================================================================

using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Demo.SaftDk.Models
{
    // =========================================================================
    //  ROOT
    // =========================================================================

    [XmlRoot("AuditFile", Namespace = SaftNamespace.DK)]
    public class AuditFile
    {
        [XmlElement("Header")]
        public AuditFileHeader Header { get; set; } = new();

        [XmlElement("MasterFiles")]
        public MasterFiles? MasterFiles { get; set; }

        /// <summary>
        /// Journal entries. Used for:
        ///   Tier 1.3 — debit/credit imbalance detection
        ///   Tier 2.1 — Benford's Law analysis
        ///   Tier 2.2 — round-number / threshold clustering
        ///   Tier 2.3 — off-hours posting detection
        /// </summary>
        [XmlElement("GeneralLedgerEntries")]
        public GeneralLedgerEntries? GeneralLedgerEntries { get; set; }

        /// <summary>
        /// Invoices. Used for:
        ///   Tier 1.1 — invoice sequence gap detection
        ///   Tier 1.2 — phantom supplier detection
        ///   Tier 1.4 — tax code misclassification
        ///   Tier 3.1 — invoice suppression (SAF-T vs Peppol)
        ///   Tier 3.2 — amount tampering (SAF-T vs Peppol)
        /// </summary>
        [XmlElement("SourceDocuments")]
        public SourceDocuments? SourceDocuments { get; set; }
    }

    public static class SaftNamespace
    {
        public const string DK = "urn:StandardAuditFile-Taxation-Financial:DK";
    }

    // =========================================================================
    //  HEADER
    // =========================================================================

    public class AuditFileHeader
    {
        [XmlElement("AuditFileVersion")]
        public string AuditFileVersion { get; set; } = "1.0";

        /// <summary>Always "DK" for Danish submissions.</summary>
        [XmlElement("AuditFileCountry")]
        public string AuditFileCountry { get; set; } = "DK";

        [XmlElement("AuditFileDateCreated")]
        public DateTime AuditFileDateCreated { get; set; }

        [XmlElement("SoftwareCompanyName")]
        public string? SoftwareCompanyName { get; set; }

        [XmlElement("SoftwareID")]
        public string? SoftwareID { get; set; }

        [XmlElement("Company")]
        public CompanyHeader Company { get; set; } = new();

        /// <summary>Always "DKK" for Danish submissions.</summary>
        [XmlElement("DefaultCurrencyCode")]
        public string DefaultCurrencyCode { get; set; } = "DKK";

        [XmlElement("SelectionCriteria")]
        public SelectionCriteria SelectionCriteria { get; set; } = new();
    }

    public class CompanyHeader
    {
        /// <summary>Danish CVR number — exactly 8 digits.</summary>
        [XmlElement("RegistrationNumber")]
        public string RegistrationNumber { get; set; } = string.Empty;

        [XmlElement("Name")]
        public string Name { get; set; } = string.Empty;

        [XmlElement("Address")]
        public Address? Address { get; set; }

        [XmlElement("TaxRegistration")]
        public TaxRegistration TaxRegistration { get; set; } = new();
    }

    public class TaxRegistration
    {
        /// <summary>
        /// For Danish VAT-registered companies this is the same value as the CVR number.
        /// Prefixed "DK" only in EU cross-border contexts — stored without prefix here.
        /// </summary>
        [XmlElement("TaxRegistrationNumber")]
        public string TaxRegistrationNumber { get; set; } = string.Empty;

        [XmlElement("TaxType")]
        public string TaxType { get; set; } = "VAT";

        [XmlElement("TaxAuthority")]
        public string? TaxAuthority { get; set; }
    }

    public class SelectionCriteria
    {
        [XmlElement("SelectionStartDate")]
        public DateTime SelectionStartDate { get; set; }

        [XmlElement("SelectionEndDate")]
        public DateTime SelectionEndDate { get; set; }

        /// <summary>Start month (1–12).</summary>
        [XmlElement("PeriodStart")]
        public int PeriodStart { get; set; }

        [XmlElement("PeriodStartYear")]
        public int PeriodStartYear { get; set; }

        /// <summary>End month (1–12).</summary>
        [XmlElement("PeriodEnd")]
        public int PeriodEnd { get; set; }

        [XmlElement("PeriodEndYear")]
        public int PeriodEndYear { get; set; }
    }

    // =========================================================================
    //  SHARED
    // =========================================================================

    public class Address
    {
        [XmlElement("StreetName")]
        public string? StreetName { get; set; }

        [XmlElement("PostalCode")]
        public string? PostalCode { get; set; }

        [XmlElement("City")]
        public string? City { get; set; }

        /// <summary>ISO 3166-1 alpha-2 (e.g. "DK", "DE").</summary>
        [XmlElement("Country")]
        public string? Country { get; set; }
    }

    public class Amount
    {
        [XmlElement("Amount")]
        public decimal Value { get; set; }

        /// <summary>ISO 4217 (e.g. "DKK").</summary>
        [XmlElement("CurrencyCode")]
        public string CurrencyCode { get; set; } = "DKK";

        /// <summary>Only required when CurrencyCode != DKK.</summary>
        [XmlElement("ExchangeRate")]
        public decimal? ExchangeRate { get; set; }
    }

    public class TaxInformation
    {
        /// <summary>Always "VAT" for Danish moms.</summary>
        [XmlElement("TaxType")]
        public string TaxType { get; set; } = "VAT";

        /// <summary>
        /// Danish VAT code. Key values for fraud detection:
        ///   S25  — Standard 25% (domestic sales)
        ///   S0   — Zero-rated (exports). Tier 1.4: flag if buyer is Danish.
        ///   KB25 — Input/purchase VAT 25%
        /// </summary>
        [XmlElement("TaxCode")]
        public string TaxCode { get; set; } = string.Empty;

        [XmlElement("TaxPercentage")]
        public decimal? TaxPercentage { get; set; }

        [XmlElement("TaxBase")]
        public decimal TaxBase { get; set; }

        [XmlElement("TaxAmount")]
        public Amount TaxAmount { get; set; } = new();
    }

    public class DocumentTotals
    {
        [XmlElement("TaxInformationTotals")]
        public List<TaxInformation> TaxInformationTotals { get; set; } = new();

        [XmlElement("NetTotal")]
        public decimal NetTotal { get; set; }

        [XmlElement("GrossTotal")]
        public decimal GrossTotal { get; set; }
    }

    // =========================================================================
    //  MASTER FILES
    // =========================================================================

    public class MasterFiles
    {
        [XmlElement("TaxTable")]
        public TaxTable? TaxTable { get; set; }

        [XmlElement("Customers")]
        public Customers? Customers { get; set; }

        /// <summary>
        /// Supplier master. Used for:
        ///   Tier 1.2 — phantom supplier detection (SupplierID in PurchaseInvoices
        ///   must have a matching entry here; RegistrationNumber cross-checked
        ///   against the CVR register).
        /// </summary>
        [XmlElement("Suppliers")]
        public Suppliers? Suppliers { get; set; }
    }

    public class TaxTable
    {
        [XmlElement("TaxTableEntry")]
        public List<TaxCodeDetails> TaxTableEntries { get; set; } = new();
    }

    public class TaxCodeDetails
    {
        [XmlElement("TaxCode")]
        public string TaxCode { get; set; } = string.Empty;

        [XmlElement("Description")]
        public string? Description { get; set; }

        [XmlElement("TaxPercentage")]
        public decimal? TaxPercentage { get; set; }
    }

    public class Customers
    {
        [XmlElement("Customer")]
        public List<Customer> Items { get; set; } = new();
    }

    public class Customer
    {
        [XmlElement("CustomerID")]
        public string CustomerID { get; set; } = string.Empty;

        /// <summary>Danish CVR number. Used for buyer country validation (Tier 1.4).</summary>
        [XmlElement("RegistrationNumber")]
        public string? RegistrationNumber { get; set; }

        [XmlElement("CompanyName")]
        public string CompanyName { get; set; } = string.Empty;

        [XmlElement("BillingAddress")]
        public Address? BillingAddress { get; set; }
    }

    public class Suppliers
    {
        [XmlElement("Supplier")]
        public List<Supplier> Items { get; set; } = new();
    }

    public class Supplier
    {
        [XmlElement("SupplierID")]
        public string SupplierID { get; set; } = string.Empty;

        /// <summary>
        /// Danish CVR number. Tier 1.2: cross-check this against the national
        /// CVR register. If not found, the supplier is phantom.
        /// </summary>
        [XmlElement("RegistrationNumber")]
        public string? RegistrationNumber { get; set; }

        [XmlElement("CompanyName")]
        public string CompanyName { get; set; } = string.Empty;

        [XmlElement("BillingAddress")]
        public Address? BillingAddress { get; set; }
    }

    // =========================================================================
    //  GENERAL LEDGER ENTRIES
    // =========================================================================

    public class GeneralLedgerEntries
    {
        [XmlElement("NumberOfEntries")]
        public int NumberOfEntries { get; set; }

        [XmlElement("TotalDebit")]
        public decimal TotalDebit { get; set; }

        [XmlElement("TotalCredit")]
        public decimal TotalCredit { get; set; }

        [XmlElement("Journal")]
        public List<Journal> Journals { get; set; } = new();
    }

    public class Journal
    {
        [XmlElement("JournalID")]
        public string JournalID { get; set; } = string.Empty;

        [XmlElement("Description")]
        public string? Description { get; set; }

        [XmlElement("Transaction")]
        public List<Transaction> Transactions { get; set; } = new();
    }

    public class Transaction
    {
        [XmlElement("TransactionID")]
        public string TransactionID { get; set; } = string.Empty;

        [XmlElement("Period")]
        public int Period { get; set; }

        [XmlElement("PeriodYear")]
        public int PeriodYear { get; set; }

        [XmlElement("TransactionDate")]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Actual system timestamp when the entry was posted (date + time).
        /// Used for Tier 2.3: off-hours / end-of-period manipulation detection.
        /// </summary>
        [XmlElement("SystemEntryDate")]
        public DateTime SystemEntryDate { get; set; }

        [XmlElement("Description")]
        public string? Description { get; set; }

        /// <summary>
        /// User account that posted the entry.
        /// Tier 2.3: multiple large reversals posted by "admin" after midnight are a red flag.
        /// </summary>
        [XmlElement("PostedByUserID")]
        public string? PostedByUserID { get; set; }

        [XmlElement("Line")]
        public List<TransactionLine> Lines { get; set; } = new();
    }

    public class TransactionLine
    {
        [XmlElement("RecordID")]
        public string RecordID { get; set; } = string.Empty;

        [XmlElement("AccountID")]
        public string AccountID { get; set; } = string.Empty;

        [XmlElement("Description")]
        public string? Description { get; set; }

        /// <summary>"D" = Debit, "C" = Credit. Tier 1.3: sum D must equal sum C per journal.</summary>
        [XmlElement("DebitCreditIndicator")]
        public string DebitCreditIndicator { get; set; } = string.Empty;

        [XmlElement("Amount")]
        public Amount Amount { get; set; } = new();

        [XmlElement("TaxInformation")]
        public TaxInformation? TaxInformation { get; set; }
    }

    // =========================================================================
    //  SOURCE DOCUMENTS
    // =========================================================================

    public class SourceDocuments
    {
        [XmlElement("SalesInvoices")]
        public InvoiceCollection? SalesInvoices { get; set; }

        [XmlElement("PurchaseInvoices")]
        public InvoiceCollection? PurchaseInvoices { get; set; }
    }

    public class InvoiceCollection
    {
        [XmlElement("NumberOfEntries")]
        public int NumberOfEntries { get; set; }

        [XmlElement("TotalDebit")]
        public decimal? TotalDebit { get; set; }

        [XmlElement("TotalCredit")]
        public decimal? TotalCredit { get; set; }

        [XmlElement("Invoice")]
        public List<Invoice> Invoices { get; set; } = new();
    }

    public class Invoice
    {
        /// <summary>
        /// Sequential invoice number. Tier 1.1: gaps in this sequence indicate
        /// suppressed invoices. Tier 3.1: matched against Peppol cbc:ID.
        /// </summary>
        [XmlElement("InvoiceNo")]
        public string InvoiceNo { get; set; } = string.Empty;

        /// <summary>References MasterFiles.Customers.Customer.CustomerID (SalesInvoices only).</summary>
        [XmlElement("CustomerID")]
        public string? CustomerID { get; set; }

        /// <summary>
        /// References MasterFiles.Suppliers.Supplier.SupplierID (PurchaseInvoices only).
        /// Tier 1.2: if this ID has no matching Supplier in MasterFiles, flag as phantom.
        /// </summary>
        [XmlElement("SupplierID")]
        public string? SupplierID { get; set; }

        /// <summary>Month number (1–12).</summary>
        [XmlElement("Period")]
        public int Period { get; set; }

        [XmlElement("PeriodYear")]
        public int PeriodYear { get; set; }

        [XmlElement("InvoiceDate")]
        public DateTime InvoiceDate { get; set; }

        /// <summary>
        /// The date that determines which VAT return period this invoice falls into.
        /// Tier 1: if TaxPointDate is pushed to a later period than InvoiceDate, flag for review.
        /// </summary>
        [XmlElement("TaxPointDate")]
        public DateTime? TaxPointDate { get; set; }

        [XmlElement("InvoiceType")]
        public string? InvoiceType { get; set; }

        [XmlElement("GLPostingDate")]
        public DateTime? GLPostingDate { get; set; }

        [XmlElement("TransactionID")]
        public string? TransactionID { get; set; }

        [XmlElement("Line")]
        public List<InvoiceLine> Lines { get; set; } = new();

        [XmlElement("DocumentTotals")]
        public DocumentTotals DocumentTotals { get; set; } = new();
    }

    public class InvoiceLine
    {
        [XmlElement("LineNumber")]
        public int LineNumber { get; set; }

        [XmlElement("AccountID")]
        public string? AccountID { get; set; }

        [XmlElement("Description")]
        public string? Description { get; set; }

        [XmlElement("Quantity")]
        public decimal? Quantity { get; set; }

        [XmlElement("UnitPrice")]
        public decimal? UnitPrice { get; set; }

        [XmlElement("LineNetAmount")]
        public decimal LineNetAmount { get; set; }

        /// <summary>
        /// Tier 1.4: TaxCode S0 (zero-rated) is only valid if the buyer is outside Denmark.
        /// Cross-check TaxCode against the buyer's country in MasterFiles.Customers.
        /// </summary>
        [XmlElement("TaxInformation")]
        public TaxInformation TaxInformation { get; set; } = new();
    }
}
